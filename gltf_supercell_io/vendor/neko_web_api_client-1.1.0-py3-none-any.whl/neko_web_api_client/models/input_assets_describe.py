from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.asset_describe_type import AssetDescribeType
from ..types import UNSET, Unset

T = TypeVar("T", bound="InputAssetsDescribe")


@_attrs_define
class InputAssetsDescribe:
    """
    Attributes:
        request_type (AssetDescribeType):
        request (str | Unset): Regex like asset name Default: ''.
    """

    request_type: AssetDescribeType
    request: str | Unset = ""
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        request_type = self.request_type.value

        request = self.request

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "requestType": request_type,
            }
        )
        if request is not UNSET:
            field_dict["request"] = request

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        request_type = AssetDescribeType(d.pop("requestType"))

        request = d.pop("request", UNSET)

        input_assets_describe = cls(
            request_type=request_type,
            request=request,
        )

        input_assets_describe.additional_properties = d
        return input_assets_describe

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
