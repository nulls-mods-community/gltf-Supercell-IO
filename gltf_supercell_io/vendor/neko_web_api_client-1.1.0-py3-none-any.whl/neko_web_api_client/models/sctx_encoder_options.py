from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.image_converter_loaders import ImageConverterLoaders
from ..models.supported_sctx_types import SupportedSCTXTypes

T = TypeVar("T", bound="SctxEncoderOptions")


@_attrs_define
class SctxEncoderOptions:
    """
    Attributes:
        source (ImageConverterLoaders):
        compress (bool):
        padding (bool):
        mipmaps (bool):
        proxy (bool):
        type_ (SupportedSCTXTypes):
        tags (list[str]):
        unknown_flag_1 (bool):
        unknown_flag_2 (bool):
    """

    source: ImageConverterLoaders
    compress: bool
    padding: bool
    mipmaps: bool
    proxy: bool
    type_: SupportedSCTXTypes
    tags: list[str]
    unknown_flag_1: bool
    unknown_flag_2: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        source = self.source.value

        compress = self.compress

        padding = self.padding

        mipmaps = self.mipmaps

        proxy = self.proxy

        type_ = self.type_.value

        tags = self.tags

        unknown_flag_1 = self.unknown_flag_1

        unknown_flag_2 = self.unknown_flag_2

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "source": source,
                "compress": compress,
                "padding": padding,
                "mipmaps": mipmaps,
                "proxy": proxy,
                "type": type_,
                "tags": tags,
                "unknownFlag1": unknown_flag_1,
                "unknownFlag2": unknown_flag_2,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        source = ImageConverterLoaders(d.pop("source"))

        compress = d.pop("compress")

        padding = d.pop("padding")

        mipmaps = d.pop("mipmaps")

        proxy = d.pop("proxy")

        type_ = SupportedSCTXTypes(d.pop("type"))

        tags = cast(list[str], d.pop("tags"))

        unknown_flag_1 = d.pop("unknownFlag1")

        unknown_flag_2 = d.pop("unknownFlag2")

        sctx_encoder_options = cls(
            source=source,
            compress=compress,
            padding=padding,
            mipmaps=mipmaps,
            proxy=proxy,
            type_=type_,
            tags=tags,
            unknown_flag_1=unknown_flag_1,
            unknown_flag_2=unknown_flag_2,
        )

        sctx_encoder_options.additional_properties = d
        return sctx_encoder_options

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
