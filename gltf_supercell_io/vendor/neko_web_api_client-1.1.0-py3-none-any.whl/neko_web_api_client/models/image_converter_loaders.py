from enum import IntEnum


class ImageConverterLoaders(IntEnum):
    AUTO = 0
    PNG = 1
    SCTX = 2

    def __str__(self) -> str:
        return str(self.value)
