from enum import Enum


class AssetDescribeType(str, Enum):
    DATABASE = "db"
    USER_FILES = "user"

    def __str__(self) -> str:
        return str(self.value)
