from enum import IntEnum


class ImageConverterEncoders(IntEnum):
    PNG = 1
    SCTX = 2
    KTX1 = 3

    def __str__(self) -> str:
        return str(self.value)
