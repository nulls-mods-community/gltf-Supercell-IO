from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.asset_describe_type import AssetDescribeType
from ...models.assets_input_body import AssetsInputBody
from ...models.assets_reference_response import AssetsReferenceResponse
from ...models.error_response import ErrorResponse
from ...models.image_converter_loaders import ImageConverterLoaders
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: AssetsInputBody | Unset = UNSET,
    request_type: AssetDescribeType,
    request: str | Unset = "",
    source: ImageConverterLoaders,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    json_request_type = request_type.value
    params["requestType"] = json_request_type

    params["request"] = request

    json_source = source.value
    params["source"] = json_source

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/texture/png",
        "params": params,
    }

    if not isinstance(body, Unset):
        _kwargs["files"] = body.to_multipart()

    headers["Content-Type"] = "multipart/form-data; boundary=+++"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AssetsReferenceResponse | ErrorResponse | None:
    if response.status_code == 200:
        response_200 = AssetsReferenceResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 429:
        response_429 = ErrorResponse.from_dict(response.json())

        return response_429

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AssetsReferenceResponse | ErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AssetsInputBody | Unset = UNSET,
    request_type: AssetDescribeType,
    request: str | Unset = "",
    source: ImageConverterLoaders,
) -> Response[AssetsReferenceResponse | ErrorResponse]:
    """
    Args:
        request_type (AssetDescribeType):
        request (str | Unset):  Default: ''.
        source (ImageConverterLoaders):
        body (AssetsInputBody | Unset): An array of file data provided by user to process

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AssetsReferenceResponse | ErrorResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        request_type=request_type,
        request=request,
        source=source,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: AssetsInputBody | Unset = UNSET,
    request_type: AssetDescribeType,
    request: str | Unset = "",
    source: ImageConverterLoaders,
) -> AssetsReferenceResponse | ErrorResponse | None:
    """
    Args:
        request_type (AssetDescribeType):
        request (str | Unset):  Default: ''.
        source (ImageConverterLoaders):
        body (AssetsInputBody | Unset): An array of file data provided by user to process

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AssetsReferenceResponse | ErrorResponse
    """

    return sync_detailed(
        client=client,
        body=body,
        request_type=request_type,
        request=request,
        source=source,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AssetsInputBody | Unset = UNSET,
    request_type: AssetDescribeType,
    request: str | Unset = "",
    source: ImageConverterLoaders,
) -> Response[AssetsReferenceResponse | ErrorResponse]:
    """
    Args:
        request_type (AssetDescribeType):
        request (str | Unset):  Default: ''.
        source (ImageConverterLoaders):
        body (AssetsInputBody | Unset): An array of file data provided by user to process

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AssetsReferenceResponse | ErrorResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        request_type=request_type,
        request=request,
        source=source,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: AssetsInputBody | Unset = UNSET,
    request_type: AssetDescribeType,
    request: str | Unset = "",
    source: ImageConverterLoaders,
) -> AssetsReferenceResponse | ErrorResponse | None:
    """
    Args:
        request_type (AssetDescribeType):
        request (str | Unset):  Default: ''.
        source (ImageConverterLoaders):
        body (AssetsInputBody | Unset): An array of file data provided by user to process

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AssetsReferenceResponse | ErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            request_type=request_type,
            request=request,
            source=source,
        )
    ).parsed
